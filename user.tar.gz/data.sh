cd /etc/openvpn/user/
for data in `ls */data | sed 's/\/data//g'`;do
printf "%-10s%20s%20s\n" "$data" "`cat $data/data`M" "`cat $data/password`"
done