#!/bin/sh
#脚本由烟雨笑编写
#qq：86248425

#################################################################################################################################################
rm -f vpnuser
sed -n "/Common Name,Real Address,Bytes Received,Bytes Sent,Connected Since/,/ROUTING TABLE/P" /etc/openvpn/log/openvpn-status.log >>vpnuser
sed -i "/Common Name,Real Address,Bytes Received,Bytes Sent,Connected Since/d" vpnuser
sed -i "/ROUTING TABLE/d" vpnuser
#################################################################################################################################################

numberid=`sed -n '$=' vpnuser`

#判断是否有用户在线
if [ -s vpnuser ]; then
echo
echo "当前用户在线数量：$numberid"
echo
else
echo
echo "当前没有用户在线"
echo
rm -f vpnuser
exit
fi

