#!/bin/sh
#脚本由烟雨笑编写
#qq：86248425
clear
echo
echo -e "\e[1;36m >         1. 创建账号 \e[0m"
echo
echo -e "\e[1;31m >         2. 删除账号 \e[0m"
echo
echo -e "\e[1;35m >         3. 修改账号 \e[0m"
echo
echo -e -n "\e[1;34m请输入数字继续执行:\e[0m" 
read menu
echo
if [ "$menu" == "1" ]; then
echo -e -n "\e[1;36m请输入账号: \e[0m" 
read vpnuser
if [ -e "/etc/openvpn/user/$vpnuser" ]; then
	echo
	echo -e -n "\e[1;36m$vpnuser已经存在,请重新输入账号: \e[0m"
	read vpnuser
if [ -e "/etc/openvpn/user/$vpnuser" ]; then
echo
echo -e -n "\e[1;31m连续两次输入错误正在退出....\e[0m"
echo
sleep 3
exit
else
echo
echo -e "\e[1;36m$vpnuser创建成功\e[0m"
fi
	else
	echo
	echo -e "\e[1;36m$vpnuser创建成功\e[0m"
fi
echo
mkdir /etc/openvpn/user/$vpnuser
echo -e -n "\e[1;36m请输入密码: \e[0m" 
read vpnpass
echo
echo "$vpnpass" >/etc/openvpn/user/$vpnuser/password
echo -e -n "\e[1;36m请输入流量限制(M为单位): \e[0m" 
read vpndata
echo
echo "$vpndata" >/etc/openvpn/user/$vpnuser/data
/etc/openvpn/user/data.sh
fi
if [ "$menu" == "2" ]; then
/etc/openvpn/user/data.sh
echo
echo -e -n "\e[1;36m请输入账号: \e[0m" 
read rmuser
if [ -e /etc/openvpn/user/$rmuser ]; then
echo
echo -e "\e[1;36m账号：$rmuser 删除成功\e[0m"
rm -rf /etc/openvpn/user/$rmuser
else
echo
echo -e "\e[1;36m账号：$rmuser 不存在删除失败\e[0m"
fi
fi
if [ "$menu" == "3" ]; then
echo -e "\e[1;35m >         1. 修改密码 \e[0m"
echo
echo -e "\e[1;35m >         2. 修改流量\e[0m"
echo
echo -e -n "\e[1;34m请输入数字继续执行:\e[0m" 
read li
if [ "$li" == "1" ]; then
echo
/etc/openvpn/user/data.sh
echo
echo -e -n "\e[1;36m请输入账号: \e[0m" 
read liuser
echo 
echo -e -n "\e[1;36m请输入新密码: \e[0m" 
read lipassword
echo "$lipassword" >/etc/openvpn/user/$liuser/password
echo
/etc/openvpn/user/data.sh
echo
fi
fi
if [ "$li" == "2" ]; then
echo
/etc/openvpn/user/data.sh
echo
echo -e -n "\e[1;36m请输入账号: \e[0m" 
read liuser
echo 
echo -e -n "\e[1;36m请输入流量: \e[0m" 
read lidata
echo "$lidata" >/etc/openvpn/user/$liuser/data
echo
/etc/openvpn/user/data.sh
echo
fi
