#!/bin/sh
TIME_STAMP=`date "+%Y-%m-%d %T"`
LOG_FILE="/www/openvpn.html"
_used="`expr $bytes_received + $bytes_sent`"
_used="`expr $_used / 1024 / 1024`"
echo "`expr  \`cat /etc/openvpn/user/$username/data\` -  $_used`"  >/etc/openvpn/user/$username/data
echo "${TIME_STAMP}: 用户断开: 用户名=\"${username}\", 使用流量=\"${_used}M\"<br>" >> ${LOG_FILE}