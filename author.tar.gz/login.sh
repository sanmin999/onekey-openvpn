#!/bin/sh
LOG_FILE="/www/openvpn.html"
USER="/etc/openvpn/user/$username"
DATA=`cat /etc/openvpn/user/$username/data M`
TIME_STAMP=`date "+%Y-%m-%d %T"`

###########################################################

if [ ! -r "${USER}" ]; then
	echo "${TIME_STAMP}: 用户不存在：用户名=\"${username}\"<br>" >> ${LOG_FILE}
	exit 1
fi

CORRECT_PASSWORD=`cat /etc/openvpn/user/$username/password`

if [ "${password}" = "${CORRECT_PASSWORD}" ]; then 
  	echo "${TIME_STAMP}: 验证成功: 用户名=\"${username}\", 剩余流量=\"${DATA}M\"<br>" >> ${LOG_FILE}
if [ "`expr  \`cat /etc/openvpn/user/$username/data\``" -gt 0 ] ;then
	exit 0
fi
	echo "${TIME_STAMP}: 流量不足: 用户名=\"${username}\"<br>" >> ${LOG_FILE}
	exit 1
fi
	echo "${TIME_STAMP}: 密码错误: 用户名=\"${username}\", 密码=\"${password}\"<br>" >> ${LOG_FILE}
	exit 1
